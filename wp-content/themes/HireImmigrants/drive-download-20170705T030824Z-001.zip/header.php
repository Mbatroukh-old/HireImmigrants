<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="css/hire-immigrants.css">
	<script src="js/hire-immigrants.js"></script>
</head>
<body>
<?php include('i/assets.svg'); ?>
<header>
	<div class="container">
		<div class="left">			
			<a href="#">
				<svg class="ico">
					<use xlink:href="#logo-c"/>
				</svg>
			</a>
		</div>
		<div class="right">
			<nav>
				<ul>
					<li><a href="#">Read</a></li>
					<li><a href="#">Watch</a></li>
					<li><a href="#">Stories</a></li>
					<li><a href="#">Reports</a></li>
					<li><a href="#">Contact</a></li>
				</ul>
			</nav>
			<div class="search">
				<svg class="ico">
					<use xlink:href="#mag-glass"/>
				</svg>
			</div>
		</div>
	</div>
</header>