<?php include('header.php'); ?>
<br>
This is the index.php file
<br>
<?php include('footer.php'); ?>