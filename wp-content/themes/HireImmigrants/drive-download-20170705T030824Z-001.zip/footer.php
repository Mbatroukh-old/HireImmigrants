This is the footer.php file.
</body>
</html>